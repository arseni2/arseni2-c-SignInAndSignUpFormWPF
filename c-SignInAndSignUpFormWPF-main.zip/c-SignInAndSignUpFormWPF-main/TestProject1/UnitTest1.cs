using SignInAndSignUpForm;

namespace TestProject1
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            bool result = RegistrationWindow.IsValidEmail("test@");
            Assert.Equal(false, result);
        }

        [Fact]
        public void Test2()
        {
            bool result = RegistrationWindow.IsEmailUnique("test@mail.ru");
            Assert.Equal(true, result);
        }

        [Fact]
        public void Test3()
        {
            bool result = RegistrationWindow.IsEmailUnique("test@mail.ri3");
            Assert.Equal(false, result);
        }

        [Fact]
        public void Test4()
        {
            bool result = MainWindow.AuthenticateUser("test@mail.ri3", "123");
            Assert.Equal(false, result);
        }

        [Fact]
        public void Test5()
        {
            bool result = MainWindow.AuthenticateUser("test@mail.ri", "test@mail.ri");
            Assert.Equal(true, result);
        }
    }
}